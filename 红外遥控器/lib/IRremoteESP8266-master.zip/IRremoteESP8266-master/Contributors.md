## Contributors of this project
- [Mark Szabo](https://github.com/markszabo/) : IR sending on ESP8266
- [Sébastien Warin](https://github.com/sebastienwarin/) (http://sebastien.warin.fr) : IR receiving on ESP8266

## Contributors of the original project (https://github.com/shirriff/Arduino-IRremote/)
These are the active contributors of this project that you may contact if there is anything you need help with or if you have suggestions. 

- [z3t0](https://github.com/z3t0) : Active Contributor and currently also the main contributor.
  * Email: zetoslab@gmail.com
  * Skype: polarised16
- [shirriff](https://github.com/shirriff) : Owner of repository and creator of library.
- [Informatic](https://github.com/Informatic) : Active contributor
- [fmeschia](https://github.com/fmeschia) : Active contributor
- [PaulStoffregen](https://github.com/paulstroffregen) : Active contributor
- [crash7](https://github.com/crash7) : Active contributor
- [Neco777](https://github.com/neco777) : Active contributor

Note: This list is being updated constantly so please let [z3t0](https://github.com/z3t0) know if you have been missed.


